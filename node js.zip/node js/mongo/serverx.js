const express = require('express');
const mongodb = require('mongodb');

const app = express();
const client = mongodb.MongoClient;
app.use(express.urlencoded({ extended: true }));
//app.use(express.static(asset);
app.set('view engine', 'ejs');
app.use(express.static(__dirname + "/asset"));
app.use(express.static(__dirname + '/views'));
let dbinstance;
client.connect("mongodb://127.0.0.1:27017")
   .then((database) => {
      dbinstance = database.db("blog"); // name of database
      if (dbinstance) {
         console.log("connected to database");
      }
      else {
         console.log("not connected to database");
      }
   })
   .catch((err) => {
      console.log(err);
   });
app.get('/', (req, res) => {
   res.render('login');
})
app.listen(5050);
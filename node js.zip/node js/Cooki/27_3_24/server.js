const express = require('express');
const app = express();
const fs = require('fs');
const cookieParser = require("cookie-parser");
const session = require("express-session");


app.use(express.static(__dirname));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(session({
    saveUninitialized: true, //create empty session
    resave: false,
    secret: "123@#abc",
    cookie: { maxAge: 60000 }
}));

function check(req, res, next) {
    if (!req.session.username) {
        return res.sendFile(__dirname + '/login.html');
    }
    next();
}

app.get(['/','/dashboard'], check, (req, res, next) => {
    res.sendFile(__dirname + '/dashboard.html');
});

app.get('/login', (req, res) => {
    if (req.session.username) {
        return res.redirect('/dashboard');
    }
    res.sendFile(__dirname + '/login.html');
});

app.post('/usercheck', (req, res) => {
    const newUsername = req.body.username; 
    fs.readFile(__dirname + '/user.json', (err, data) => {
        if (err) {
            console.error(err);
        }
        let users = JSON.parse(data);
        const existingUser = users.find(user => user.username === newUsername);
        if (!existingUser) {
            res.send("user not exsist");
        }
        req.session.username = newUsername;
        console.log(req.session,"log in");
        res.redirect('/dashboard');
    });
});

app.get('/logout',(req,res)=>{
    req.session.destroy();
    console.log(req.session);
    res.redirect('/login');
})

app.listen(3030,(err)=>{
    if(err){
        console.log(err);
    }else{
        console.log("listening on port 3000 ...");
    }
})

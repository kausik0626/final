const express=require('express  ');

const app=express();

const PORT=5050;
const http = require("http");
const fs = require("fs");
const url = require("url");             
const server = http.createServer((req, res) => {
    console.log(req.url);
    let urlParse = url.parse(req.url, true);
    if (req.url == "/") {
        fs.readFile(__dirname + "/index.html", "utf-8", (err, data) => {
            if (err) {
                res.write("error");
            }
            else {
                res.writeHead(200, "content-type", "text/html");
                res.write(data);
            }
            res.end();
        })
    }
    if (urlParse.pathname == "/add") {
        fs.readFile(__dirname + "/user.json", "utf-8", (err, data) => {
            data = JSON.parse(data);
            const flag = false;
            data.forEach(e => {
                if (e.username == urlParse.query.username) {
                    flag = true;
                }
            });

            if (flag == true) {
                res.end("already exist");
            }
            else {
                data.push(urlParse.query);
                fs.writeFileSync(__dirname + "/user.json", JSON.stringify(data));
                res.end("DONE");
            }
        });
    }

})
server.listen(5000, (err) => {
    if (err) {
        console.log(err);
    }
    else {
        console.log("server started");
    }
})
const express=require('express');
const session =require('express-session');
const bodyparser= require('body-parser');
const app =express();
app.use(bodyparser.urlencoded({extended:true}));
app.use(bodyparser.json());
app.listen(5050);
app.use(session({
    secret : 'keyboard',
    resave:false,
    saveUninitialized:true
}));
var user =[
    {username : 'abc', password : 'abc'},
    {username : 'xyz', password : 'xyz'}
];
app.get('/login',(req, res) => {
res.sendFile('/views/login.html',{root:'./public'});

})
var userAuth =(req,res,next)=>{
    console.log(req.body);
    const username=user.filter(user=>user.username==req.body.username)
    if(username.length>0    ){
        next();
    }
    else{
        res.redirect('/login');
    }
}
app.post('/login',userAuth,(req, res) => {
    res.send("I'am authenticated")
})
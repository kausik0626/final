
const fs =require("fs");

// Sync
// fs.writeFileSync('./test.text','Hey Kausik');



// Async
// fs.writeFile('./test.text','Hey Kausik Sahoo', (err)=>{

// });

// File reading

// let result =fs.readFileSync("./contact.txt","utf-8");
// console.log(result);

// Async readFile function doesn't return Anything

// fs.readFile("./contact.txt" ,"utf-8",(err,result)=>{
//     if(err){
//         console.log("Error",err);
//     }
//     else{
//         console.log(result);
//     }
// })

// Appened File

// fs.appendFileSync("./test.text", 'Hey there\n' );

// copy Files

// fs.cpSync("test.text","./copy.txt");

// Delete File 

// fs.unlinkSync("./copy.txt");

// Check Status of a file

// console.log(fs.statSync("test.text"));


// const os=require('os');
// console.log(os.cpus().length);
const fs = require('fs');
const express = require('express');
const  app = express();
app.use(express.static(__dirname)); //m
app.use(express.json()); // m
app.use(express.urlencoded({ extended: false }));// m

app.get("/", (req, res) => {
   
    res.sendFile(__dirname + "/01.html");
})
app.post("/delete", (req, res) => {

    const newUsername = req.body.username; 
   
    fs.readFile(__dirname+'/user.json','utf8',(err,data)=>{
        if (err) {
            console.error(err);
        }
        let users = JSON.parse(data);
   
        let nusers=users.filter(user=>user.username!==newUsername);
        if(nusers.length==users.length){

            
            res.send("There is Nothing to delete");
        }
        else{
        fs.writeFileSync(__dirname+'/user.json', JSON.stringify(nusers));
        console.log('Data deleted successfully.');
        }
    })
    })
    app.listen(7626,(err)=>{
        if (err) {
            console.log(err);
        }
        else {
            console.log("server started");
        }
    }
);
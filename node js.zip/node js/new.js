console.log("hey Kausik Are you ready !!");
// const math=require("./math")
// console. log("Math value is",math.add(5, 3 ));
// console.log(window);
// function add(a,b){
//     return a+b;
// }
const math=require('./math');
console.log(math.add(5,2));
console.log(math.sub(8,5));
const express=require('express');
const app=express();
const cookie=require('cookie-parser');
const session=require('express-session');
const fs=require('fs');
let dbinstance;
const mongodb=require('mongodb');
const multer= require('multer');
const client=mongodb.MongoClient;
app.use(express.static(__dirname ));
app.use(express.urlencoded({extended: false}));
app.set('view engine','ejs');
app.use(cookie());
app.use(session({
    saveUninitialized: true,
    resave: false,
secret:"1234@kausik",
 cookie:{maxAge:60000}
}));

const storage=multer.diskStorage({
    destination:(req,file,cb)=>{
        console.log(file);
        cb(null,__dirname+'/asset')
    },
    filename:(req,file,cb)=>{
        let name=Date.now()+'.jpg';
        cb(null,name)
    }
});
const filter=(req,file,cb)=>{
    let ext=file.mimetype.split('/')[1];
    if(ext=='jpg'||ext=='jpeg'){
        cb(null,true)
    }
    else{
        cb(new Error("Invalid file extension"),false);
    }
}
const upload =multer({storage:storage,fileFilter:filter,limits:{fileSize:10*1024*1024}});
client.connect('mongodb+srv://Prince:0626@cluster0.r8ftbxm.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0').then((data)=>{
dbinstance= data.db('mydb');
console.log('Database Connected');
})
app.get(['/','/login'],check1,(req,res)=>{
    res.render('login');
    //res.send("Hello");
})
app.get('/dash',check,(req,res)=>{
    res.render('dashboard');

   
})
app.get('/signup',check1,(req,res)=>{
    res.render('sign');

   
})
app.get('/h',(req,res)=>{
    res.render('home');
})
function check(req,res,next){
    if(!req.session.user){
       res.redirect('/login');
    }
    else{
        next();
    }
}
function check1(req,res,next){
    if(req.session.user){
        res.redirect('/signup');
     }
     else{
         next();
     }
}

app.post('/login',(req,res)=>{
    dbinstance.collection('profile').find(req.body).toArray().then((data)=>{
        if(data.length>0){
            req.session.user=data[0];
            res.redirect('/dash');
        }
        else{
            res.redirect('/signup');
        }
    }).catch((err)=>{
        console.log(err);
    })
})

app.post('/signup',(req,res)=>{
    dbinstance.collection('profile').find(req.body).toArray().then((data)=>{
        if(data.length==0){
            dbinstance.collection('profile').insertOne(req.body).then((dt)=>{
                console.log(dt);
                res.send("user Added successfully");
            })
        }
    })
})
app.post('/abc',upload.single('img') ,(req,res)=>{
    req.body.img=req.file.filename;
    dbinstance.collection('posts').insertOne(req.body).then((dt)=>{
        console.log(dt);
        res.send("user Added successfully");
    })

})
app.listen(5000,(err)=>{
    if(err){
        console.log(err);
    }
    else{
        console.log("listening on port 5000 ...");
    }
});

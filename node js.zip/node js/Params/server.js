const express=require('express');
const app=express();
//app.use(express.urlencoded({extended:false}));
app.get('/',(req, res) => {
  res.sendFile(__dirname + '/index.html');

})

// app.use((req,res,next) => {
//     console.log(req.url);
//     next();
// })
const arr=[1,2,3,4,5,6,7,8,9,10,11];
console.log(arr);
function del(dl8){

    arr.forEach(el=>{
        if(el==dl8){
            arr.splice(arr.indexOf(el),1);
        }
    })
   
}
let dl8;
app.get('/dlt/:value',(req, res) => {
    console.log(req.params.value);
dl8=req.params.value;
del(dl8);
res.json(JSON.stringify({'message':'value deleted'}))
// console.log(dl8)
console.log(arr);

})
// del();
// app.get('/:value',(req,res)=>{
//   //  const data = mongoClient.find({id:req.params.value})
//     //res.send(req.params.value);
//     res.send(req.params.value);
// })
// console.log(arr);
app.listen(3050,(err)=>{
    if(err) console.log(err);
    else console.log("server is running on port 3050");
})
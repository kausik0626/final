const fs = require("fs");
// const cookieParser = require("cookie-parser");
const mongodb = require("mongodb");
const express = require("express");
//const { sign } = require("crypto");

const app = express();
// const session = express("express-session");
let dbinstance;
const clint = mongodb.MongoClient;
clint.connect("mongodb://127.0.0.1:27017")
    .then((database) => {
        dbinstance = database.db("blog"); // name of database
        console.log("connected to database");
    })
    .catch((err) => {
        console.log(err);
    });
app.use(express.static(__dirname));
app.use(express.json());

app.use(express.urlencoded({ extended: false }));
// app.use(cookieParser());
// app.use(
//   session({
//     saveUninitialized: true, //create empty session
//     resave: false,
//     secret: "123@#abc",
//     cookie: { maxAge: 60000 },
//   })
// );

let user;
app.post('/sign', (req, res) => {
    dbinstance.collection('users').find({ username: req.body.username }).toArray().then((data) => {
        if (data.length == 0) {
            dbinstance.collection('users').insertOne(req.body).then((dt) => {
                console.log(dt);
                res.send("user Added successfully");
            })
        }
        else {
           res.sendFile(__dirname+'/login.html');
        }
    })
})
app.get("/", (req, res) => {
    res.sendFile(__dirname + "/sign.html");
});

app.get('/login',(req,res)=>{
    res.sendFile(__dirname + "/login.html");
})

app.post('/add', (req, res) => {
    dbinstance.collection('users').find({username:req.body.username}).toArray().then((data)=>{
        if(data.length >0) {
            user = data[0];
           res.sendFile(__dirname+'/dash.html');
        }
        else{
            res.sendFile(__dirname + "/sign.html");
        }
    })
})

app.get('/logout', (req, res) => {
    console.log("sign in");

    res.sendFile(__dirname +"/login.html");
})
app.get('/delete', (req, res) => {
    dbinstance.collection('users').deleteOne({username:user.username}).then((data)=>{
        console.log(data);
        res.send("data deleted successfully");
    }).catch((err)=>{
        console.log(err);
    })
})
app.listen(6050);

const express = require('express');
const fs = require('fs');
const app = express();

app.use(express.static(__dirname));  //its creates endpoint by the name of file names from the applied path
app.use(express.json());  //its parses playload from fecth or html req 
app.use(express.urlencoded({extended:false})); //its parses playload from form

app.get('/',(req,res)=>{
    res.sendFile(__dirname + '/clogin.html');
})

app.post('/add',(req,res)=>{
    console.log(req.body);
    fs.readFile(__dirname + '/user.json',(err,data)=>{
        if(err) console.error("error to fetch");
        else{
            data = JSON.parse(data);
            data.push(req.body);
            fs.writeFile(__dirname + '/user.json',JSON.stringify(data),(err)=>{
                if(err) console.error();
            })
            //1. res.send(data);
            res.status(200).json(data);
        }
    })

})

app.get('/showusername',(req,res)=>{
    fs.readFile(__dirname + '/user.json',(err,data)=>{
        if(err) console.error("error to fetch");
        else{
            res.send(data);
        }
    })
})


app.listen(3000,(err)=>{
    if(err) console.error(err.stack());
    else console.log("Server started at port 3000...");
});
const express= require("express");
const users = require("./rest.json"); 
const app=express();
const PORT=5050;
app.get('/users',(req, res)=>{
const html= `<ol>
${users.map((user)=>`<li>${user.first_name}</li>`).join("")}
</ol>`;
return res.send(html); 
});
app.get('/api/users',(req, res) => {
    return res.json(users);
})

app.listen(PORT,()=>console.log("Server Started Sucessfully!"));

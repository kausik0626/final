const fs = require('fs');
const express = require('express');
const app = express();
app.use(express.static(__dirname));
app.use(express.json());
app.use(express.urlencoded({ extended: false }))

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/02.html');
})
app.get('/add', (req, res) => {

    fs.readFile(__dirname + '/product.json', (err, data) => {
        if (err) {
            console.error(err);
        }
        else {
            res.send(data);
        }
    });
});
app.listen(7626, (err) => {
    if (err) console.log(err);
    else {
        console.log("Server is running on port 7626");
    }
})
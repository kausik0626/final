const express = require('express');
const app = express();
const fs=require('fs');
const bodyParser=require('body-parser');
app.use(bodyParser.urlencoded({extended:true}));
const PORT= 7626;
app.use(express.static('public'));
app.post('/signup', (req, res)=>{
    const{username}=req.body;
    
})

const express = require('express');
const app = express();
const fs = require('fs');
const multer = require('multer');
const cookie = require('cookie-parser');
const session = require("express-session");
const mongodb = require("mongodb");
const client = mongodb.MongoClient;

client.connect("mongodb+srv://dibyendushyamal2004:Dibyendu%4070479@cluster0.b2jxanb.mongodb.net/").then((database) => {
    dbstance = database.db("LoginPage");
    
})

app.use(express.urlencoded({ extended: false }));
app.use(express.json());

app.use(express.static(__dirname));
app.use(express.static(__dirname + "/asset"));
app.use(cookie());
app.set("view engine", "ejs");
app.use(session({
    saveUninitialized: true,
    resave: false,
    secret: "abcd",
    
}));


function check1(req, res, next) {
    if (!req.session.user) {
        res.redirect("/");
    }
    else {
        next();
    }
}
function check2(req, res, next) {
    if (req.session.user) {
        res.redirect("/dashboard");
    }
    else {
        next();
    }
}
app.get("/", check2, (req, res) => {
    res.render("login");
})
app.get("/signup", check2, (req, res) => {
    res.render("signup");
})
app.get("/home", check1, (req, res) => {
    res.render("home");
})
app.get("/dashboard", check1, (req, res) => {
    dbstance.collection("image").find().toArray().then((data) => {
        res.render("dashboard", { data: data });
    })
})

app.get("/abc", (req, res) => {
    res.render("home");
})

app.post("/login", (req, res) => {
    dbstance.collection("login").find(req.body).toArray().then((data) => {
        if (data.length == 1) {
            req.session.user = data[0];
            res.redirect("/dashboard");
        }
        else {
            res.redirect("/signup");
        }
    }).catch((err) => {
        console.log("Error");
    })
})

app.post("/signup", (req, res) => {
    dbstance.collection("login").find(req.body).toArray().then((data) => {
        if (data.length == 1) {
            res.redirect("/login");
        } else {
            dbstance.collection("login").insertOne(req.body).then(d => {
                res.send("User Added");
            }).catch((err) => {
                console.log("error");
            })
        }
    }).catch((err) => {
        console.log("error");
    })
})


const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, __dirname + "/asset");
    },
    filename: (req, file, cb) => {
        let name = Date.now() + ".jpg";
        cb(null, name);
    }
});
const filter = (req, file, cb) => {
    let ext = file.mimetype.split('/')[1];
    if (ext == 'jpg' || ext == 'jpeg') {
        cb(null, true);
    }
    else {
        cb(new Error("Invalid file extension", false));
    }
}
const maxSize = 10 * 1024 * 1024;

const upload = multer({ storage: storage, fileFilter: filter, limits: { fileSize: maxSize } });

app.post("/home", upload.single("image"), (req, res) => {
    req.body.image = req.file.filename;
    dbstance.collection("image").insertOne(req.body).then(d => {
        console.log(req.body);
        res.send(" Image Added");
    }).catch((err) => {
        console.log(error);
    })
})


app.listen(7000, console.log("server Started"));